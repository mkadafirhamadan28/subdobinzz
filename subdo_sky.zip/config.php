<?php
// Config

$zone_id = 'd4a112fb8d2ec0da7729ec3a0c281c0e';
$fazriganz = 'fFZHp6tMJRStrFrUGNf6M1tlAKsqLOOwVBtewBPE'; //apikey 
$domen = 'skycom.biz.id';//nama domen
$ips = 'value="167.99.151.117"';
$wea = 'https://wa.me/6288287505731';
$host = '  <h1> TOOLS <strong>  KYY  </strong> HOSTING </h1>';// nama host