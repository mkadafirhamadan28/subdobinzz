<html>
 <head>
  <script language="JavaScript">
    window.alert('Mau Sewa Web? Tekan Ok');
    window.location.href='https://wa.me/6289523956468?text=sewaweb';
    </script>
 </head>
 <body></body>
</html>