<?php
// Config

$zone_id = '8392bab2e423837a9f814db590c6949e';
$fazriganz = 'rYZuE-PPvK63myH4UP7odAtKW1f6h5Mwbrpslx4P'; //apikey 
$domen = 'clickk1new.web.id';//nama domen
$ips = 'value="167.99.151.117"';
$wea = 'https://wa.me/6288287505731';
$host = '  <h1> TOOLS <strong>  KYY  </strong> HOSTING </h1>';// nama host